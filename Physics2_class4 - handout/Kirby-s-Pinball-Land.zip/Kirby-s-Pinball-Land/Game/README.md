# Kirby's Pinball Land

Kirby's Pinball Land is a pinball game featuring Kirby with some of his enemies from his games. This game was originally released from the Game Boy. 

## Usage

This game is played using these keys in the keyboard:

* Left bumper with left arrow.

* Right bumper with right arrow.

* Kicker with down arrow.

* Restart with enter.

* Exit the game with Escape.

Apart from these keys, there is a debug key with the use of the mouse:

* Activate mouse joint and show all shapes with F1.

* Activate mouse joint with left button of the mouse.

* Deactivate mouse joint with releasing left button of the mouse.

* Move mouse joint with movement of the mouse.

## Authors
* Arnau Falgueras Garcia de Atocha
    * Github account: Arnau77(https://github.com/Arnau77)

* Bernat Casañas Massip
    * Github account: BernatCasanas(https://github.com/BernatCasanas)

## Github link
https://github.com/Falcas-Games/Kirby-s-Pinball-Land

## Original game link
https://arcadespot.com/game/kirbys-pinball-land/

## Differences with the original game
* We just have 1 level.
* Each level has 4 camera changes, we just have 2.
* The movement of the ghost is drawing a rectangle instead of drawing a circle.
* We change the playability of the demon. we made it simple.
* The element next to bar is disabled.
* Few playability items are disabled.
* Starting animations (we made it simple).
* Font of the puntuation.
* UI position elements changed


